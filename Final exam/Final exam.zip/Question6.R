leverdata = read.csv("liverDisorder.csv", header = FALSE, col.names = c("mcv", "aap", "sgpt", "sgot", "gammagt", "drinks", "selector"))

#correlation plot
library(corrplot)
res = cor(leverdata)
corrplot(res)

#taking mcv and gammagt columns
x = leverdata[, c("mcv", "gammagt")]
plot(x,pch = 19,xlab = expression(x[1]),ylab = expression(x[2]))
fit = kmeans(x, 4)
plot(x,col=fit$cluster)
points(fit$center,col='brown',pch=8,cex=1)
